﻿namespace tastaturatelefon
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.textBox2 = new System.Windows.Forms.TextBox();
            this.ctrlbuton12 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton11 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton10 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton9 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton8 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton7 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton6 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton5 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton4 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton3 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton2 = new tastaturatelefon.ctrlbuton();
            this.ctrlbuton1 = new tastaturatelefon.ctrlbuton();
            this.textBox3 = new System.Windows.Forms.TextBox();
            this.SuspendLayout();
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(22, 10);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(276, 20);
            this.textBox1.TabIndex = 12;
            this.textBox1.TextChanged += new System.EventHandler(this.textBox1_TextChanged);
            // 
            // textBox2
            // 
            this.textBox2.Location = new System.Drawing.Point(22, 459);
            this.textBox2.Name = "textBox2";
            this.textBox2.Size = new System.Drawing.Size(276, 20);
            this.textBox2.TabIndex = 13;
            // 
            // ctrlbuton12
            // 
            this.ctrlbuton12.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton12.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton12.Location = new System.Drawing.Point(210, 353);
            this.ctrlbuton12.Name = "ctrlbuton12";
            this.ctrlbuton12.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton12.TabIndex = 25;
            // 
            // ctrlbuton11
            // 
            this.ctrlbuton11.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton11.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton11.Location = new System.Drawing.Point(116, 353);
            this.ctrlbuton11.Name = "ctrlbuton11";
            this.ctrlbuton11.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton11.TabIndex = 24;
            // 
            // ctrlbuton10
            // 
            this.ctrlbuton10.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton10.Location = new System.Drawing.Point(22, 353);
            this.ctrlbuton10.Name = "ctrlbuton10";
            this.ctrlbuton10.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton10.TabIndex = 23;
            // 
            // ctrlbuton9
            // 
            this.ctrlbuton9.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton9.Location = new System.Drawing.Point(210, 248);
            this.ctrlbuton9.Name = "ctrlbuton9";
            this.ctrlbuton9.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton9.TabIndex = 22;
            // 
            // ctrlbuton8
            // 
            this.ctrlbuton8.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton8.Location = new System.Drawing.Point(116, 248);
            this.ctrlbuton8.Name = "ctrlbuton8";
            this.ctrlbuton8.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton8.TabIndex = 21;
            // 
            // ctrlbuton7
            // 
            this.ctrlbuton7.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton7.Location = new System.Drawing.Point(22, 248);
            this.ctrlbuton7.Name = "ctrlbuton7";
            this.ctrlbuton7.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton7.TabIndex = 20;
            // 
            // ctrlbuton6
            // 
            this.ctrlbuton6.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton6.Location = new System.Drawing.Point(210, 143);
            this.ctrlbuton6.Name = "ctrlbuton6";
            this.ctrlbuton6.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton6.TabIndex = 19;
            // 
            // ctrlbuton5
            // 
            this.ctrlbuton5.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton5.Location = new System.Drawing.Point(116, 141);
            this.ctrlbuton5.Name = "ctrlbuton5";
            this.ctrlbuton5.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton5.TabIndex = 18;
            // 
            // ctrlbuton4
            // 
            this.ctrlbuton4.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton4.Location = new System.Drawing.Point(22, 141);
            this.ctrlbuton4.Name = "ctrlbuton4";
            this.ctrlbuton4.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton4.TabIndex = 17;
            // 
            // ctrlbuton3
            // 
            this.ctrlbuton3.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton3.Location = new System.Drawing.Point(210, 36);
            this.ctrlbuton3.Name = "ctrlbuton3";
            this.ctrlbuton3.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton3.TabIndex = 16;
            // 
            // ctrlbuton2
            // 
            this.ctrlbuton2.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton2.Location = new System.Drawing.Point(116, 36);
            this.ctrlbuton2.Name = "ctrlbuton2";
            this.ctrlbuton2.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton2.TabIndex = 15;
            // 
            // ctrlbuton1
            // 
            this.ctrlbuton1.BackColor = System.Drawing.SystemColors.ActiveBorder;
            this.ctrlbuton1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.ctrlbuton1.Location = new System.Drawing.Point(22, 36);
            this.ctrlbuton1.Name = "ctrlbuton1";
            this.ctrlbuton1.Size = new System.Drawing.Size(88, 99);
            this.ctrlbuton1.TabIndex = 14;
            // 
            // textBox3
            // 
            this.textBox3.Location = new System.Drawing.Point(22, 485);
            this.textBox3.Name = "textBox3";
            this.textBox3.Size = new System.Drawing.Size(276, 20);
            this.textBox3.TabIndex = 26;
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(326, 535);
            this.Controls.Add(this.textBox3);
            this.Controls.Add(this.ctrlbuton12);
            this.Controls.Add(this.ctrlbuton11);
            this.Controls.Add(this.ctrlbuton10);
            this.Controls.Add(this.ctrlbuton9);
            this.Controls.Add(this.ctrlbuton8);
            this.Controls.Add(this.ctrlbuton7);
            this.Controls.Add(this.ctrlbuton6);
            this.Controls.Add(this.ctrlbuton5);
            this.Controls.Add(this.ctrlbuton4);
            this.Controls.Add(this.ctrlbuton3);
            this.Controls.Add(this.ctrlbuton2);
            this.Controls.Add(this.ctrlbuton1);
            this.Controls.Add(this.textBox2);
            this.Controls.Add(this.textBox1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.TextBox textBox2;
        private ctrlbuton ctrlbuton1;
        private ctrlbuton ctrlbuton2;
        private ctrlbuton ctrlbuton3;
        private ctrlbuton ctrlbuton4;
        private ctrlbuton ctrlbuton5;
        private ctrlbuton ctrlbuton6;
        private ctrlbuton ctrlbuton7;
        private ctrlbuton ctrlbuton8;
        private ctrlbuton ctrlbuton9;
        private ctrlbuton ctrlbuton10;
        private ctrlbuton ctrlbuton11;
        private ctrlbuton ctrlbuton12;
        private System.Windows.Forms.TextBox textBox3;
    }
}

