﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace tastaturatelefon
{
    public class buton
    {
        public char nr;
        public List<char> litere = new List<char>(7);
        
    }
}
