/*
Jeff Weeks
CSC 172: Science of Data Structures
University of Rochester
 */
public class HashNode {
	
	public Object data;
	public HashNode next;

}
